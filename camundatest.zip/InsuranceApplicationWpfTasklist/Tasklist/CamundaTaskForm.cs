﻿using CamundaClient.Dto;

namespace InsuranceApplicationWpfTasklist
{
    internal interface CamundaTaskForm
    {
        void initialize(TasklistWindow tasklist, HumanTask task);
    }
}